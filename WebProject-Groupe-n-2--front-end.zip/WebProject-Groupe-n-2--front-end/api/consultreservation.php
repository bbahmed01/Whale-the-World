<?php

include 'database.php';
$posts = [];
$sql = "SELECT * FROM reservation order by id desc limit 4";
if($result = $db->query($sql))
{
$i = 0;
while($row = $result->fetch_assoc())
{
$posts[$i]['name'] = $row['Clientname'];
$posts[$i]['mail'] = $row['mail'];
$posts[$i]['tel'] = $row['numtel'];
$posts[$i]['dr'] = $row['reservationDate'];
$posts[$i]['an'] = $row['nbAdult'];
$posts[$i]['kn'] = $row['nbEnfants'];
$posts[$i]['mi'] = $row['autreinfo'];
$i++;
}
echo json_encode($posts);
}
else
{
http_response_code(404);
}
?>