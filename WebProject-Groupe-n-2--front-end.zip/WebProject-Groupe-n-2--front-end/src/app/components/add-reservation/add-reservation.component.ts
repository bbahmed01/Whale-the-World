import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-reservation',
  templateUrl: './add-reservation.component.html',
  styleUrls: ['./add-reservation.component.css']
})
export class AddReservationComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  gotodelete(){ this.route.navigate(['/deletereservation'])}
  gotoadd(){ this.route.navigate(['/addreservation'])}
  gotoconsult(){ this.route.navigate(['/consultreservation'])}
  gotoupdate(){ this.route.navigate(['/updatereservation'])}
  gotosignin(){ this.route.navigate(['/signin'])}
  gotosignup(){ this.route.navigate(['/signup'])}
  gotomain(){ this.route.navigate(['/main'])}
  gotoindex(){ this.route.navigate(['/'])}
}
