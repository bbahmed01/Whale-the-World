import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  gotodelete(){ this.route.navigate(['/deletereservation'])}
  gotoadd(){ this.route.navigate(['/addreservation'])}
  gotoconsult(){ this.route.navigate(['/consultreservation'])}
  gotoupdate(){ this.route.navigate(['/updatereservation'])}
  gotosignin(){ this.route.navigate(['/signin'])}
  gotosignup(){ this.route.navigate(['/signup'])}
  gotomain(){ this.route.navigate(['/main'])}
  gotoindex(){ this.route.navigate(['/'])}
}
