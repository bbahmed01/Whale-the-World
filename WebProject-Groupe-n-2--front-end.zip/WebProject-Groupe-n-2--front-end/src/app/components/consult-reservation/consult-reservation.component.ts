import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-consult-reservation',
  templateUrl: './consult-reservation.component.html',
  styleUrls: ['./consult-reservation.component.css']
})
export class ConsultReservationComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit(): void {
  }
  gotodelete(){ this.route.navigate(['/deletereservation'])}
  gotoadd(){ this.route.navigate(['/addreservation'])}
  gotoconsult(){ this.route.navigate(['/consultreservation'])}
  gotoupdate(){ this.route.navigate(['/updatereservation'])}
  gotosignin(){ this.route.navigate(['/signin'])}
  gotosignup(){ this.route.navigate(['/signup'])}
  gotomain(){ this.route.navigate(['/main'])}
  gotoindex(){ this.route.navigate(['/'])}
}
