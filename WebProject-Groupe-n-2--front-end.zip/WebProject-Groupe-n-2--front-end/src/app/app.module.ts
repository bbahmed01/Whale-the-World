import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule, routingcomponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndexComponent } from './components/index/index.component';
import { AddReservationComponent } from './components/add-reservation/add-reservation.component';
import { DeleteReservationComponent } from './components/delete-reservation/delete-reservation.component';
import { MainPageComponent } from './components/main-page/main-page.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ConsultReservationComponent } from './components/consult-reservation/consult-reservation.component';
import { UpdateReservationComponent } from './components/update-reservation/update-reservation.component';


@NgModule({
  declarations: [
    AppComponent,
    routingcomponent,
    ConsultReservationComponent,
    UpdateReservationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot([
      { path: '' , component: IndexComponent},
      { path: 'app-add-reservation' , component: AddReservationComponent },
      { path: 'delete-reservation' , component: DeleteReservationComponent},
      { path: 'main' , component: MainPageComponent},
      { path: 'signin' , component: SignInComponent},
      { path: 'signup' , component: SignUpComponent},
      { path: 'consult-reservation.component' , component: ConsultReservationComponent},
      { path: 'update-reservation.component' , component: UpdateReservationComponent}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }  
