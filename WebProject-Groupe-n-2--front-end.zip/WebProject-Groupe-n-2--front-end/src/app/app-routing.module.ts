import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndexComponent } from './components/index/index.component';
import { AddReservationComponent } from './components/add-reservation/add-reservation.component';
import { DeleteReservationComponent } from './components/delete-reservation/delete-reservation.component';
import { MainPageComponent } from './components/main-page/main-page.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ConsultReservationComponent } from './components/consult-reservation/consult-reservation.component';
import { UpdateReservationComponent } from './components/update-reservation/update-reservation.component';
import { consultreservationComponent } from './components/consultreservation/consultreservation.component';

const routes: Routes = [
  { path: '' , component: IndexComponent},
  { path: 'addreservation' , component: AddReservationComponent },
  { path: 'deletereservation' , component: DeleteReservationComponent},
  { path: 'main' , component: MainPageComponent},
  { path: 'signin' , component: SignInComponent},
  { path: 'signup' , component: SignUpComponent},
  { path: 'consultreservation' , component: ConsultReservationComponent},
  { path: 'updatereservation' , component: UpdateReservationComponent},
  { path: 'consultreservation', component: consultreservationComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponent = [IndexComponent, AddReservationComponent, ConsultReservationComponent, UpdateReservationComponent,  DeleteReservationComponent, MainPageComponent, SignInComponent, SignUpComponent]
